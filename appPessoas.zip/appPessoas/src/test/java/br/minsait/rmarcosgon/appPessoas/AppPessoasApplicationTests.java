package br.minsait.rmarcosgon.appPessoas;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AppPessoasApplicationTests {

	@Test
	void contextLoads() {
	}

}
