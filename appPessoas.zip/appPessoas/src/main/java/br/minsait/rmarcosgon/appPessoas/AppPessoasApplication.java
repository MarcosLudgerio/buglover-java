package br.minsait.rmarcosgon.appPessoas;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AppPessoasApplication {

	public static void main(String[] args) {
		SpringApplication.run(AppPessoasApplication.class, args);
	}

}
