package br.minsait.rmarcosgon.AppProdutos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AppProdutosApplicationTests {

	@Test
	void contextLoads() {
	}

}
